import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "نظام محاسبي | أسناد صرف وقبض",
  description: "واجهة تطبيق محاسبي عربية لإدارة أسناد الصرف والقبض والحسابات والتقارير.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body className="min-h-screen bg-slate-950 text-slate-100 antialiased">{children}</body>
    </html>
  );
}
